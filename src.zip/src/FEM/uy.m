function f=uy(node)

f=(3*(node-1)+2);
