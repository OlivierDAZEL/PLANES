function numdof=dofdeplacement(noeud,type,direction)


numdof=type*(noeud-1)+direction;