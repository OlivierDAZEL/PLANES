phi=0.95;
sig=42000;
alpha=1.100;
LCV=1.50E-05;
LCT=4.500E-05;
