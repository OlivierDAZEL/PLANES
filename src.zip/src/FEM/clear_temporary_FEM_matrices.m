clear i_k0_pem01;
clear j_k0_pem01;
clear v_k0_pem01;
clear i_k1_pem01;
clear j_k1_pem01;
clear v_k1_pem01;
clear i_m_pem01;
clear j_m_pem01;
clear v_m_pem01;
clear i_h_pem01;
clear j_h_pem01;
clear v_h_pem01;
clear i_q_pem01;
clear j_q_pem01;
clear v_q_pem01;
clear i_c_pem01;
clear j_c_pem01;
clear v_c_pem01;
clear i_cp_pem01;
clear j_cp_pem01;
clear v_cp_pem01;



clear i_k0_pem98;
clear j_k0_pem98;
clear v_k0_pem98;
clear j_k1_pem98;
clear v_k1_pem98;
clear i_m_pem98;
clear j_m_pem98;
clear v_m_pem98;
clear i_h_pem98;
clear j_h_pem98;
clear v_h_pem98;
clear i_q_pem98;
clear j_q_pem98;
clear v_q_pem98;
clear i_c_pem98;
clear j_c_pem98;
clear v_c_pem98;

clear i_k0_elastic;
clear j_k0_elastic;
clear v_k0_elastic;
clear i_k1_elastic;
clear j_k1_elastic;
clear i_m_elastic;
clear j_m_elastic;
clear v_m_elastic;


clear i_h_acoustic;
clear j_h_acoustic;
clear v_h_acoustic;
clear i_q_acoustic;
clear j_q_acoustic;
clear v_q_acoustic;

clear i_h_eqf;
clear j_h_eqf;
clear v_h_eqf;
clear i_q_eqf;
clear j_q_eqf;
clear v_q_eqf;

clear i_h_limp;
clear j_h_limp;
clear v_h_limp;
clear i_q_limp;
clear j_q_limp;
clear v_q_limp;
