E_solide=67000000000.0;
nu_solide=0.34E+00;
eta_solide=0.0001;
rho_solide=2700E+00;

lambda_solide=(1+1i*eta_solide)*(E_solide*nu_solide)/((1+nu_solide)*(1-2*nu_solide));
mu_solide=(1+1i*eta_solide)*(E_solide)/(2*(1+nu_solide));


