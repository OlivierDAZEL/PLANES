i_k0_pem01(1,:)=[];
j_k0_pem01(1,:)=[];
v_k0_pem01(1,:)=[];
i_k1_pem01(1,:)=[];
j_k1_pem01(1,:)=[];
v_k1_pem01(1,:)=[];
i_m_pem01(1,:)=[];
j_m_pem01(1,:)=[];
v_m_pem01(1,:)=[];
i_h_pem01(1,:)=[];
j_h_pem01(1,:)=[];
v_h_pem01(1,:)=[];
i_q_pem01(1,:)=[];
j_q_pem01(1,:)=[];
v_q_pem01(1,:)=[];
i_c_pem01(1,:)=[];
j_c_pem01(1,:)=[];
v_c_pem01(1,:)=[];
i_cp_pem01(1,:)=[];
j_cp_pem01(1,:)=[];
v_cp_pem01(1,:)=[];



i_k0_pem98(1,:)=[];
j_k0_pem98(1,:)=[];
v_k0_pem98(1,:)=[];
i_k1_pem98(1,:)=[];
j_k1_pem98(1,:)=[];
v_k1_pem98(1,:)=[];
i_m_pem98(1,:)=[];
j_m_pem98(1,:)=[];
v_m_pem98(1,:)=[];
i_h_pem98(1,:)=[];
j_h_pem98(1,:)=[];
v_h_pem98(1,:)=[];
i_q_pem98(1,:)=[];
j_q_pem98(1,:)=[];
v_q_pem98(1,:)=[];
i_c_pem98(1,:)=[];
j_c_pem98(1,:)=[];
v_c_pem98(1,:)=[];

i_k0_elas(1,:)=[];
j_k0_elas(1,:)=[];
v_k0_elas(1,:)=[];
i_k1_elas(1,:)=[];
j_k1_elas(1,:)=[];
v_k1_elas(1,:)=[];
i_m_elas(1,:)=[];
j_m_elas(1,:)=[];
v_m_elas(1,:)=[];


i_h_acoustic(1,:)=[];
j_h_acoustic(1,:)=[];
v_h_acoustic(1,:)=[];
i_q_acoustic(1,:)=[];
j_q_acoustic(1,:)=[];
v_q_acoustic(1,:)=[];


i_h_eqf(1,:)=[];
j_h_eqf(1,:)=[];
v_h_eqf(1,:)=[];
i_q_eqf(1,:)=[];
j_q_eqf(1,:)=[];
v_q_eqf(1,:)=[];

i_h_limp(1,:)=[];
j_h_limp(1,:)=[];
v_h_limp(1,:)=[];
i_q_limp(1,:)=[];
j_q_limp(1,:)=[];
v_q_limp(1,:)=[];


