E_solide=4.968424852675948D+10;
nu_solide=0.454021058288132D+00;
eta_solide=0.00;
rho_solide=7800.00E+00;

lambda_solide=(1+1i*eta_solide)*(E_solide*nu_solide)/((1+nu_solide)*(1-2*nu_solide))
mu_solide=(1+1i*eta_solide)*(E_solide)/(2*(1+nu_solide))


