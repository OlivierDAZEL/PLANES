function f=ux(node)

f=(3*(node-1)+1);
