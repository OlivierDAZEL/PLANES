function f=p(node)

f=3*node;
