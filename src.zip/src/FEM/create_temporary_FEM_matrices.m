i_k0_pem01=zeros(1,nb_media.pem01);
j_k0_pem01=zeros(1,nb_media.pem01);
v_k0_pem01=zeros(1,nb_media.pem01);
i_k1_pem01=zeros(1,nb_media.pem01);
j_k1_pem01=zeros(1,nb_media.pem01);
v_k1_pem01=zeros(1,nb_media.pem01);
i_m_pem01=zeros(1,nb_media.pem01);
j_m_pem01=zeros(1,nb_media.pem01);
v_m_pem01=zeros(1,nb_media.pem01);
i_h_pem01=zeros(1,nb_media.pem01);
j_h_pem01=zeros(1,nb_media.pem01);
v_h_pem01=zeros(1,nb_media.pem01);
i_q_pem01=zeros(1,nb_media.pem01);
j_q_pem01=zeros(1,nb_media.pem01);
v_q_pem01=zeros(1,nb_media.pem01);
i_c_pem01=zeros(1,nb_media.pem01);
j_c_pem01=zeros(1,nb_media.pem01);
v_c_pem01=zeros(1,nb_media.pem01);
i_cp_pem01=zeros(1,nb_media.pem01);
j_cp_pem01=zeros(1,nb_media.pem01);
v_cp_pem01=zeros(1,nb_media.pem01);



i_k0_pem98=zeros(1,nb_media.pem98);
j_k0_pem98=zeros(1,nb_media.pem98);
v_k0_pem98=zeros(1,nb_media.pem98);
i_k1_pem98=zeros(1,nb_media.pem98);
j_k1_pem98=zeros(1,nb_media.pem98);
v_k1_pem98=zeros(1,nb_media.pem98);
i_m_pem98=zeros(1,nb_media.pem98);
j_m_pem98=zeros(1,nb_media.pem98);
v_m_pem98=zeros(1,nb_media.pem98);
i_h_pem98=zeros(1,nb_media.pem98);
j_h_pem98=zeros(1,nb_media.pem98);
v_h_pem98=zeros(1,nb_media.pem98);
i_q_pem98=zeros(1,nb_media.pem98);
j_q_pem98=zeros(1,nb_media.pem98);
v_q_pem98=zeros(1,nb_media.pem98);
i_c_pem98=zeros(1,nb_media.pem98);
j_c_pem98=zeros(1,nb_media.pem98);
v_c_pem98=zeros(1,nb_media.pem98);

i_k0_elas=zeros(1,nb_media.elas);
j_k0_elas=zeros(1,nb_media.elas);
v_k0_elas=zeros(1,nb_media.elas);
i_k1_elas=zeros(1,nb_media.elas);
j_k1_elas=zeros(1,nb_media.elas);
v_k1_elas=zeros(1,nb_media.elas);
i_m_elas=zeros(1,nb_media.elas);
j_m_elas=zeros(1,nb_media.elas);
v_m_elas=zeros(1,nb_media.elas);


i_h_acoustic=zeros(1,nb_media.acou);
j_h_acoustic=zeros(1,nb_media.acou);
v_h_acoustic=zeros(1,nb_media.acou);
i_q_acoustic=zeros(1,nb_media.acou);
j_q_acoustic=zeros(1,nb_media.acou);
v_q_acoustic=zeros(1,nb_media.acou);

i_h_eqf=zeros(1,nb_media.eqf);
j_h_eqf=zeros(1,nb_media.eqf);
v_h_eqf=zeros(1,nb_media.eqf);
i_q_eqf=zeros(1,nb_media.eqf);
j_q_eqf=zeros(1,nb_media.eqf);
v_q_eqf=zeros(1,nb_media.eqf);

i_h_limp=zeros(1,nb_media.limp);
j_h_limp=zeros(1,nb_media.limp);
v_h_limp=zeros(1,nb_media.limp);
i_q_limp=zeros(1,nb_media.limp);
j_q_limp=zeros(1,nb_media.limp);
v_q_limp=zeros(1,nb_media.limp);

H_acou=sparse(3*nb_nodes,3*nb_nodes);
Q_acou=sparse(3*nb_nodes,3*nb_nodes);




